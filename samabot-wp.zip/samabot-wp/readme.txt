=== SamaBot — Assistant IA WhatsApp & Web ===
Contributors: samabot
Tags: chatbot, whatsapp, ia, assistant, wolof, senegal, ecommerce
Requires at least: 5.8
Tested up to: 6.4
Requires PHP: 7.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Intégrez SamaBot, l'assistant IA en wolof et français, sur votre site WordPress en 2 clics.

== Description ==

**SamaBot** est un assistant IA conçu pour les commerces sénégalais. Il répond automatiquement à vos clients en **wolof et français**, prend des commandes, gère les rendez-vous et envoie les notifications via **WhatsApp**.

= Fonctionnalités =

* 💬 **Bulle de chat flottante** sur tout votre site
* 🛍️ **Catalogue produits** avec shortcode et bloc Gutenberg
* ⭐ **Avis clients** affichés automatiquement (social proof)
* 📊 **Note moyenne** en badge
* 🖼️ **Chat intégré** dans n'importe quelle page (iframe)
* 🎨 **Personnalisation** de la couleur
* 📱 Compatible **WooCommerce, Elementor, Divi**, et tous les thèmes
* ⚡ **Cache intelligent** (5-10 min) pour des performances optimales

= Pour qui ? =

* Restaurants (menu en ligne, commandes WhatsApp)
* Salons de beauté (prise de RDV)
* Boutiques (catalogue + commandes)
* Pharmacies (commandes médicaments)
* Tout commerce qui veut automatiser sa relation client

= Comment ça marche ? =

1. Créez votre bot sur [samabot.app/setup](https://samabot.app/setup) (gratuit)
2. Récupérez votre **Bot ID**
3. Installez ce plugin
4. Collez votre Bot ID dans **Réglages → SamaBot**
5. ✅ La bulle de chat apparaît sur tout votre site !

== Installation ==

1. Téléchargez le ZIP du plugin
2. Dans WordPress: **Extensions → Ajouter → Téléverser une extension**
3. Sélectionnez le fichier ZIP et cliquez **Installer maintenant**
4. **Activez** le plugin
5. Allez dans **Réglages → SamaBot**
6. Entrez votre Bot ID et enregistrez

== Frequently Asked Questions ==

= Comment obtenir un Bot ID ? =

Créez votre compte gratuit sur [samabot.app/setup](https://samabot.app/setup). Le Bot ID s'affiche après la création.

= Le plugin ralentit-il mon site ? =

Non. Le widget se charge en mode `async` et le catalogue est mis en cache 5-10 min.

= Compatible WooCommerce ? =

Oui, parfaitement. Vous pouvez ajouter le shortcode `[samabot_chat]` sur les pages produit pour pousser à commander via WhatsApp.

= Combien ça coûte ? =

Le plugin est **gratuit**. SamaBot a un plan gratuit + des plans payants selon le volume de messages.

== Screenshots ==

1. La page de réglages dans WordPress
2. Le widget bulle de chat sur le site
3. Le catalogue affiché via shortcode
4. Les avis clients affichés
5. L'éditeur Gutenberg avec les blocs SamaBot

== Changelog ==

= 1.0.0 =
* Première version
* Widget bulle de chat
* 5 shortcodes (catalogue, chat, avis, rating, embed)
* 3 blocs Gutenberg
* Cache intégré
* Page de réglages

== Upgrade Notice ==

= 1.0.0 =
Première version stable.
