<?php
/**
 * Plugin Name: SamaBot — Assistant IA WhatsApp & Web
 * Plugin URI: https://samabot.app
 * Description: Intégrez SamaBot (assistant IA en wolof et français) sur votre site. Bulle de chat, catalogue produits, avis clients — tout en 2 clics.
 * Version: 1.0.0
 * Author: SamaBot
 * Author URI: https://samabot.app
 * License: GPL v2 or later
 * Text Domain: samabot
 */

// Sécurité: empêche l'accès direct
if (!defined('ABSPATH')) exit;

define('SAMABOT_VERSION', '1.0.0');
define('SAMABOT_API_BASE', 'https://api.samabot.app');
define('SAMABOT_PLUGIN_URL', plugin_dir_url(__FILE__));

// ============================================
// 1. RÉGLAGES — Page d'admin
// ============================================
class SamaBot_Settings {
    public function __construct() {
        add_action('admin_menu', [$this, 'add_menu']);
        add_action('admin_init', [$this, 'register_settings']);
    }

    public function add_menu() {
        add_options_page(
            'SamaBot',
            '🤖 SamaBot',
            'manage_options',
            'samabot',
            [$this, 'render_page']
        );
    }

    public function register_settings() {
        register_setting('samabot_settings', 'samabot_bot_id');
        register_setting('samabot_settings', 'samabot_couleur');
        register_setting('samabot_settings', 'samabot_widget_actif');
        register_setting('samabot_settings', 'samabot_pages_excluded');
    }

    public function render_page() {
        $bot_id = get_option('samabot_bot_id', '');
        $couleur = get_option('samabot_couleur', '#00c875');
        $widget_actif = get_option('samabot_widget_actif', '1');
        $excluded = get_option('samabot_pages_excluded', '');
        ?>
        <div class="wrap" style="max-width:860px">
            <h1 style="display:flex;align-items:center;gap:10px"><span style="font-size:32px">🤖</span> SamaBot — Réglages</h1>

            <?php if (!$bot_id): ?>
                <div class="notice notice-warning" style="padding:14px">
                    <strong>👋 Bienvenue !</strong> Pour commencer, créez votre bot sur
                    <a href="https://api.samabot.app/setup" target="_blank">samabot.app/setup</a>,
                    puis collez votre <strong>Bot ID</strong> ci-dessous.
                </div>
            <?php else: ?>
                <div class="notice notice-success" style="padding:14px">
                    ✅ <strong>SamaBot est connecté !</strong>
                    <a href="https://api.samabot.app/dashboard/<?php echo esc_attr($bot_id); ?>" target="_blank">Ouvrir le dashboard SamaBot →</a>
                </div>
            <?php endif; ?>

            <form method="post" action="options.php" style="background:#fff;padding:24px;border:1px solid #e5e5e5;border-radius:8px;margin-top:20px">
                <?php settings_fields('samabot_settings'); ?>

                <h2 style="margin-top:0">📋 Configuration de base</h2>

                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="samabot_bot_id">Bot ID</label>
                        </th>
                        <td>
                            <input type="text" id="samabot_bot_id" name="samabot_bot_id"
                                   value="<?php echo esc_attr($bot_id); ?>" class="regular-text"
                                   placeholder="ex: sargal-mov2odnz" required/>
                            <p class="description">
                                Trouvez votre Bot ID sur le dashboard SamaBot (URL ou code widget).
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="samabot_couleur">Couleur principale</label>
                        </th>
                        <td>
                            <input type="text" id="samabot_couleur" name="samabot_couleur"
                                   value="<?php echo esc_attr($couleur); ?>" class="regular-text"
                                   placeholder="#00c875"/>
                            <input type="color" value="<?php echo esc_attr($couleur); ?>"
                                   onchange="document.getElementById('samabot_couleur').value=this.value"
                                   style="vertical-align:middle;margin-left:10px"/>
                            <p class="description">Couleur de la bulle de chat et des éléments.</p>
                        </td>
                    </tr>
                </table>

                <h2 style="margin-top:30px">💬 Widget bulle de chat</h2>

                <table class="form-table">
                    <tr>
                        <th scope="row">Activer la bulle</th>
                        <td>
                            <label>
                                <input type="checkbox" name="samabot_widget_actif" value="1"
                                       <?php checked($widget_actif, '1'); ?>/>
                                Afficher la bulle de chat sur tout le site
                            </label>
                            <p class="description">
                                Une bulle ronde apparaît en bas à droite de chaque page.
                                Décochez si vous voulez utiliser uniquement les shortcodes.
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="samabot_pages_excluded">Pages exclues</label>
                        </th>
                        <td>
                            <textarea id="samabot_pages_excluded" name="samabot_pages_excluded"
                                      rows="3" cols="50" placeholder="checkout, mon-compte, panier"><?php echo esc_textarea($excluded); ?></textarea>
                            <p class="description">
                                Slugs des pages où ne PAS afficher la bulle, séparés par des virgules.
                            </p>
                        </td>
                    </tr>
                </table>

                <?php submit_button('Enregistrer les réglages'); ?>
            </form>

            <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:20px;margin-top:24px">
                <h2 style="margin-top:0">🧱 Shortcodes disponibles</h2>
                <p>Utilisez ces shortcodes dans n'importe quelle page ou article :</p>

                <h3>📦 Afficher le catalogue</h3>
                <code style="display:block;background:#0a1a0f;color:#a0e0c0;padding:12px;border-radius:6px;margin:8px 0">
                [samabot_catalogue limit="8"]
                </code>
                <p>Affiche tous les produits avec photo, prix et bouton "Commander". Paramètres :</p>
                <ul style="margin-left:20px">
                    <li><code>limit</code> — nombre max de produits (défaut: 12)</li>
                    <li><code>columns</code> — colonnes (défaut: auto)</li>
                </ul>

                <h3>💬 Bouton "Discuter avec le bot"</h3>
                <code style="display:block;background:#0a1a0f;color:#a0e0c0;padding:12px;border-radius:6px;margin:8px 0">
                [samabot_chat texte="Discuter sur WhatsApp"]
                </code>

                <h3>⭐ Avis clients (social proof)</h3>
                <code style="display:block;background:#0a1a0f;color:#a0e0c0;padding:12px;border-radius:6px;margin:8px 0">
                [samabot_avis limit="5"]
                </code>

                <h3>📊 Note moyenne (badge)</h3>
                <code style="display:block;background:#0a1a0f;color:#a0e0c0;padding:12px;border-radius:6px;margin:8px 0">
                [samabot_rating]
                </code>

                <h3>🖼️ Chat intégré (iframe)</h3>
                <code style="display:block;background:#0a1a0f;color:#a0e0c0;padding:12px;border-radius:6px;margin:8px 0">
                [samabot_chat_embed height="600"]
                </code>
            </div>

            <div style="background:#fef3c7;border:1px solid #fcd34d;border-radius:8px;padding:20px;margin-top:20px">
                <h2 style="margin-top:0">💡 Astuces</h2>
                <ul style="margin-left:20px">
                    <li><strong>WooCommerce :</strong> ajoutez <code>[samabot_chat]</code> sur la page produit pour pousser à commander via WhatsApp</li>
                    <li><strong>Page d'accueil :</strong> mettez la note moyenne en haut avec <code>[samabot_rating]</code></li>
                    <li><strong>Page "À propos" :</strong> affichez les avis clients avec <code>[samabot_avis]</code></li>
                    <li><strong>Page "Menu" / "Boutique" :</strong> affichez tout le catalogue avec <code>[samabot_catalogue]</code></li>
                </ul>
            </div>

            <p style="text-align:center;color:#666;margin-top:30px;font-size:13px">
                SamaBot v<?php echo SAMABOT_VERSION; ?> ·
                <a href="https://api.samabot.app/api/docs" target="_blank">Documentation API</a> ·
                <a href="https://samabot.app" target="_blank">samabot.app</a>
            </p>
        </div>
        <?php
    }
}
new SamaBot_Settings();

// ============================================
// 2. WIDGET BULLE — injection auto sur le site
// ============================================
add_action('wp_footer', function() {
    $bot_id = get_option('samabot_bot_id', '');
    $widget_actif = get_option('samabot_widget_actif', '1');
    if (!$bot_id || $widget_actif !== '1') return;

    // Vérifier exclusions
    $excluded = get_option('samabot_pages_excluded', '');
    if ($excluded) {
        $slugs = array_map('trim', explode(',', $excluded));
        global $post;
        if ($post && in_array($post->post_name, $slugs)) return;
    }

    $couleur = get_option('samabot_couleur', '#00c875');
    ?>
    <script>
      window.SamaBotConfig = {
        botId: '<?php echo esc_js($bot_id); ?>',
        couleur: '<?php echo esc_js($couleur); ?>'
      };
    </script>
    <script src="<?php echo esc_url(SAMABOT_API_BASE); ?>/widget.js" async></script>
    <?php
});

// ============================================
// 3. SHORTCODES
// ============================================

// 🛍️ Catalogue
add_shortcode('samabot_catalogue', function($atts) {
    $atts = shortcode_atts([
        'limit' => 12,
        'bot_id' => '',
        'columns' => 'auto'
    ], $atts);

    $bot_id = $atts['bot_id'] ?: get_option('samabot_bot_id', '');
    if (!$bot_id) return '<p style="color:#dc2626">⚠️ SamaBot: Bot ID non configuré (Réglages → SamaBot)</p>';

    // Cache 5 min
    $cache_key = 'samabot_cat_' . md5($bot_id);
    $data = get_transient($cache_key);
    if ($data === false) {
        $url = SAMABOT_API_BASE . '/api/v1/bots/' . $bot_id . '/catalogue';
        $resp = wp_remote_get($url, ['timeout' => 5]);
        if (is_wp_error($resp)) return '<p>Catalogue indisponible</p>';
        $data = json_decode(wp_remote_retrieve_body($resp), true);
        if (!empty($data)) set_transient($cache_key, $data, 300);
    }

    if (empty($data['catalogue'])) return '<p>Aucun produit disponible.</p>';

    $couleur = $data['bot']['couleur'] ?? '#00c875';
    $cols = $atts['columns'] === 'auto' ? 'repeat(auto-fit,minmax(220px,1fr))' : 'repeat(' . intval($atts['columns']) . ',1fr)';

    $html = '<div class="samabot-catalogue" style="display:grid;grid-template-columns:' . esc_attr($cols) . ';gap:16px;margin:24px 0">';

    foreach (array_slice($data['catalogue'], 0, intval($atts['limit'])) as $p) {
        $html .= '<div style="background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:16px;text-align:center;transition:transform .2s" onmouseover="this.style.transform=\'translateY(-3px)\'" onmouseout="this.style.transform=\'\'">';

        if (!empty($p['photo'])) {
            $html .= '<img src="' . esc_url($p['photo']) . '" alt="' . esc_attr($p['nom']) . '" style="width:100%;height:140px;object-fit:cover;border-radius:8px;margin-bottom:12px;display:block"/>';
        } else {
            $html .= '<div style="font-size:60px;height:140px;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,' . esc_attr($couleur) . '22,' . esc_attr($couleur) . '44);border-radius:8px;margin-bottom:12px">' . esc_html($p['emoji'] ?? '🛍️') . '</div>';
        }

        $html .= '<h3 style="font-size:16px;font-weight:700;margin:0 0 6px;color:#0a1a0f">' . esc_html($p['nom']) . '</h3>';

        if (!empty($p['desc'])) {
            $html .= '<p style="font-size:13px;color:#666;margin:0 0 10px;line-height:1.4">' . esc_html(mb_substr($p['desc'], 0, 80)) . '</p>';
        }

        $html .= '<div style="font-size:20px;font-weight:800;color:' . esc_attr($couleur) . ';margin:8px 0">' . number_format($p['prix'], 0, ',', ' ') . ' FCFA</div>';

        $html .= '<a href="' . esc_url(SAMABOT_API_BASE . '/chat/' . $bot_id) . '" target="_blank" style="display:inline-block;background:' . esc_attr($couleur) . ';color:#000;padding:10px 20px;border-radius:8px;text-decoration:none;font-weight:700;font-size:13px;margin-top:6px">Commander →</a>';

        $html .= '</div>';
    }

    $html .= '</div>';
    return $html;
});

// 💬 Bouton "Discuter avec le bot"
add_shortcode('samabot_chat', function($atts) {
    $atts = shortcode_atts([
        'texte' => '💬 Discuter avec nous',
        'bot_id' => '',
        'style' => 'fullwidth'
    ], $atts);

    $bot_id = $atts['bot_id'] ?: get_option('samabot_bot_id', '');
    if (!$bot_id) return '';

    $couleur = get_option('samabot_couleur', '#00c875');
    $width = $atts['style'] === 'inline' ? 'auto' : '100%';
    $display = $atts['style'] === 'inline' ? 'inline-block' : 'block';

    return '<a href="' . esc_url(SAMABOT_API_BASE . '/chat/' . $bot_id) . '" target="_blank" style="display:' . $display . ';width:' . $width . ';background:' . esc_attr($couleur) . ';color:#000;padding:14px 24px;border-radius:10px;text-decoration:none;font-weight:700;text-align:center;font-size:15px;margin:10px 0;box-sizing:border-box;font-family:inherit">' . esc_html($atts['texte']) . '</a>';
});

// ⭐ Avis clients
add_shortcode('samabot_avis', function($atts) {
    $atts = shortcode_atts([
        'limit' => 5,
        'bot_id' => ''
    ], $atts);

    $bot_id = $atts['bot_id'] ?: get_option('samabot_bot_id', '');
    if (!$bot_id) return '';

    $cache_key = 'samabot_avis_' . md5($bot_id . '_' . $atts['limit']);
    $data = get_transient($cache_key);
    if ($data === false) {
        $url = SAMABOT_API_BASE . '/api/v1/bots/' . $bot_id . '/avis?limit=' . intval($atts['limit']);
        $resp = wp_remote_get($url, ['timeout' => 5]);
        if (is_wp_error($resp)) return '';
        $data = json_decode(wp_remote_retrieve_body($resp), true);
        if (!empty($data)) set_transient($cache_key, $data, 600); // 10 min
    }

    if (empty($data['avis'])) return '<p style="color:#666;text-align:center">Pas encore d\'avis.</p>';

    $couleur = get_option('samabot_couleur', '#00c875');
    $html = '<div class="samabot-avis" style="margin:24px 0">';
    $html .= '<div style="text-align:center;margin-bottom:20px"><span style="font-size:32px;font-weight:800;color:' . esc_attr($couleur) . '">⭐ ' . esc_html($data['moyenne']) . '/5</span> <span style="color:#666;font-size:14px">(' . intval($data['total']) . ' avis)</span></div>';

    foreach ($data['avis'] as $a) {
        $stars = str_repeat('⭐', $a['note']) . str_repeat('☆', 5 - $a['note']);
        $html .= '<div style="background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:16px;margin-bottom:12px">';
        $html .= '<div style="font-size:18px;color:#f59e0b;margin-bottom:8px">' . $stars . '</div>';
        if (!empty($a['commentaire'])) {
            $html .= '<p style="margin:0 0 8px;color:#0a1a0f;font-style:italic">"' . esc_html($a['commentaire']) . '"</p>';
        }
        if (!empty($a['reponse'])) {
            $html .= '<div style="background:#f0fdf4;border-left:3px solid ' . esc_attr($couleur) . ';padding:10px;border-radius:4px;margin-top:10px"><strong style="font-size:11px;color:#166534">↳ Réponse</strong><p style="margin:4px 0 0;font-size:13px">' . esc_html($a['reponse']) . '</p></div>';
        }
        $html .= '<div style="font-size:11px;color:#999;margin-top:6px">' . date_i18n('d M Y', strtotime($a['date'])) . '</div>';
        $html .= '</div>';
    }
    $html .= '</div>';
    return $html;
});

// 📊 Note moyenne (badge)
add_shortcode('samabot_rating', function($atts) {
    $atts = shortcode_atts(['bot_id' => ''], $atts);
    $bot_id = $atts['bot_id'] ?: get_option('samabot_bot_id', '');
    if (!$bot_id) return '';

    $cache_key = 'samabot_stats_' . md5($bot_id);
    $data = get_transient($cache_key);
    if ($data === false) {
        $url = SAMABOT_API_BASE . '/api/v1/bots/' . $bot_id . '/stats';
        $resp = wp_remote_get($url, ['timeout' => 5]);
        if (is_wp_error($resp)) return '';
        $data = json_decode(wp_remote_retrieve_body($resp), true);
        if (!empty($data)) set_transient($cache_key, $data, 600);
    }

    if (empty($data['avg_rating'])) return '';

    return '<span style="display:inline-block;background:#fef9c3;color:#854d0e;padding:6px 14px;border-radius:20px;font-weight:700;font-size:14px">⭐ ' . esc_html($data['avg_rating']) . ' (' . intval($data['total_reviews']) . ' avis)</span>';
});

// 🖼️ Chat intégré (iframe)
add_shortcode('samabot_chat_embed', function($atts) {
    $atts = shortcode_atts([
        'height' => 600,
        'bot_id' => ''
    ], $atts);

    $bot_id = $atts['bot_id'] ?: get_option('samabot_bot_id', '');
    if (!$bot_id) return '';

    return '<iframe src="' . esc_url(SAMABOT_API_BASE . '/chat/' . $bot_id) . '" style="width:100%;height:' . intval($atts['height']) . 'px;border:none;border-radius:12px;box-shadow:0 4px 16px rgba(0,0,0,.08)" loading="lazy"></iframe>';
});

// ============================================
// 4. BLOC GUTENBERG (éditeur visuel WordPress)
// ============================================
add_action('init', function() {
    if (!function_exists('register_block_type')) return;

    wp_register_script(
        'samabot-block',
        SAMABOT_PLUGIN_URL . 'block.js',
        ['wp-blocks', 'wp-element', 'wp-editor', 'wp-components'],
        SAMABOT_VERSION
    );

    register_block_type('samabot/catalogue', [
        'editor_script' => 'samabot-block',
        'render_callback' => function($attrs) {
            $limit = $attrs['limit'] ?? 8;
            return do_shortcode('[samabot_catalogue limit="' . intval($limit) . '"]');
        },
        'attributes' => [
            'limit' => ['type' => 'number', 'default' => 8]
        ]
    ]);

    register_block_type('samabot/chat-button', [
        'editor_script' => 'samabot-block',
        'render_callback' => function($attrs) {
            $texte = $attrs['texte'] ?? '💬 Discuter avec nous';
            return do_shortcode('[samabot_chat texte="' . esc_attr($texte) . '"]');
        },
        'attributes' => [
            'texte' => ['type' => 'string', 'default' => '💬 Discuter avec nous']
        ]
    ]);

    register_block_type('samabot/avis', [
        'editor_script' => 'samabot-block',
        'render_callback' => function($attrs) {
            $limit = $attrs['limit'] ?? 5;
            return do_shortcode('[samabot_avis limit="' . intval($limit) . '"]');
        },
        'attributes' => [
            'limit' => ['type' => 'number', 'default' => 5]
        ]
    ]);
});

// ============================================
// 5. ACTIVATION / DÉSACTIVATION
// ============================================
register_activation_hook(__FILE__, function() {
    add_option('samabot_widget_actif', '1');
    add_option('samabot_couleur', '#00c875');
});

register_deactivation_hook(__FILE__, function() {
    // Nettoyer le cache transient
    global $wpdb;
    $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_samabot_%'");
});

// Lien "Réglages" sur la page Plugins
add_filter('plugin_action_links_' . plugin_basename(__FILE__), function($links) {
    array_unshift($links, '<a href="' . admin_url('options-general.php?page=samabot') . '">Réglages</a>');
    return $links;
});
