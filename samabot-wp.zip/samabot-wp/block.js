(function(blocks, element, blockEditor, components){
  var el = element.createElement;
  var InspectorControls = (blockEditor && blockEditor.InspectorControls) || (wp.editor && wp.editor.InspectorControls);
  var PanelBody = components.PanelBody;
  var TextControl = components.TextControl;
  var RangeControl = components.RangeControl;

  // 🛍️ Bloc Catalogue
  blocks.registerBlockType('samabot/catalogue', {
    title: 'SamaBot — Catalogue',
    icon: 'cart',
    category: 'widgets',
    description: 'Affiche votre catalogue de produits SamaBot',
    attributes: {
      limit: { type: 'number', default: 8 }
    },
    edit: function(props){
      return el('div', { style:{ background:'#f0fdf4', border:'2px dashed #00c875', borderRadius:8, padding:24, textAlign:'center' } },
        el('div', { style:{ fontSize:40, marginBottom:8 } }, '🛍️'),
        el('strong', { style:{ display:'block', fontSize:16, color:'#0a1a0f' } }, 'Catalogue SamaBot'),
        el('p', { style:{ color:'#5a7060', fontSize:13, marginTop:6 } }, 'Affiche ' + props.attributes.limit + ' produits avec photos, prix, et bouton "Commander"'),
        el(InspectorControls, {},
          el(PanelBody, { title:'Réglages', initialOpen:true },
            el(RangeControl, {
              label: 'Nombre de produits',
              value: props.attributes.limit,
              onChange: function(v){ props.setAttributes({ limit: v }); },
              min: 1, max: 24
            })
          )
        )
      );
    },
    save: function(){ return null; } // server-side render
  });

  // 💬 Bloc Bouton Chat
  blocks.registerBlockType('samabot/chat-button', {
    title: 'SamaBot — Bouton Chat',
    icon: 'format-chat',
    category: 'widgets',
    description: 'Bouton pour discuter avec votre bot SamaBot',
    attributes: {
      texte: { type: 'string', default: '💬 Discuter avec nous' }
    },
    edit: function(props){
      return el('div', { style:{ background:'#f0fdf4', border:'2px dashed #00c875', borderRadius:8, padding:20, textAlign:'center' } },
        el('div', { style:{ fontSize:30, marginBottom:6 } }, '💬'),
        el('strong', { style:{ fontSize:14 } }, 'Bouton Chat: "' + props.attributes.texte + '"'),
        el(InspectorControls, {},
          el(PanelBody, { title:'Réglages', initialOpen:true },
            el(TextControl, {
              label: 'Texte du bouton',
              value: props.attributes.texte,
              onChange: function(v){ props.setAttributes({ texte: v }); }
            })
          )
        )
      );
    },
    save: function(){ return null; }
  });

  // ⭐ Bloc Avis
  blocks.registerBlockType('samabot/avis', {
    title: 'SamaBot — Avis clients',
    icon: 'star-filled',
    category: 'widgets',
    description: 'Affiche les avis clients de votre bot',
    attributes: {
      limit: { type: 'number', default: 5 }
    },
    edit: function(props){
      return el('div', { style:{ background:'#fef9c3', border:'2px dashed #f59e0b', borderRadius:8, padding:24, textAlign:'center' } },
        el('div', { style:{ fontSize:40, marginBottom:8 } }, '⭐'),
        el('strong', { style:{ display:'block', fontSize:16, color:'#0a1a0f' } }, 'Avis clients SamaBot'),
        el('p', { style:{ color:'#5a7060', fontSize:13, marginTop:6 } }, 'Affiche ' + props.attributes.limit + ' avis avec note moyenne'),
        el(InspectorControls, {},
          el(PanelBody, { title:'Réglages', initialOpen:true },
            el(RangeControl, {
              label: 'Nombre d\'avis',
              value: props.attributes.limit,
              onChange: function(v){ props.setAttributes({ limit: v }); },
              min: 1, max: 20
            })
          )
        )
      );
    },
    save: function(){ return null; }
  });
})(window.wp.blocks, window.wp.element, window.wp.blockEditor || window.wp.editor, window.wp.components);
